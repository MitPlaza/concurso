<x-guest-layout>


    <div class="max-w-full">
        <img class="h-auto max-w-full" src="/images/Banner-Mantita-Cumple-Mes.jpg" alt="image description">
    </div>


    <div>
        <section class="  mt-14 mb-28">
            <div class="py-8 px-4 mx-auto bg-gray-50 bg-opacity-80 border rounded-2xl text-center lg:py-6"
                style="max-width: 1000px;">
                <h3 style="color:#706D6A"
                    class="mb-4 text-xl font-regular tracking-tight leading-none  md:text-2xl lg:text-4xl dark:text-white">
                    ¡Gracias por participar en nuestro concurso<br> #CreceConBambino!</h3>

                <p class="mb-8 text-lg font-normal text-gray-500 lg:text-xl sm:px-6 lg:px-6 dark:text-gray-900">
                    Anunciaremos a los ganadores cada mes en nuestras redes sociales.!
                </p>
            </div>

        </section>

    </div>






    <div class="py-8 px-4 mx-auto  text-center lg:py-6" style="max-width: 1000px;">
        <p class="mt-8 text-lg font-normal text-gray-800 lg:text-md sm:px-6 lg:px-6 dark:text-gray-900">¡No pierdas la
            oportunidad de crear recuerdos inolvidables y ganar fabulosos premios!</p>
        <p class="mt-2 text-sm font-normal text-stone-600 lg:text-sm sm:px-6 lg:px-6 dark:text-gray-900">
            #CrececonBambino #BambinoChile #ConcursoBambino #PrimerCumpleaños #MomentosInolvidables</p>
    </div>




</x-guest-layout>