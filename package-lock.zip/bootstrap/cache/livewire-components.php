<?php return array (
  'lista-seleccionados' => 'App\\Http\\Livewire\\ListaSeleccionados',
  'toggle-selection' => 'App\\Http\\Livewire\\ToggleSelection',
);