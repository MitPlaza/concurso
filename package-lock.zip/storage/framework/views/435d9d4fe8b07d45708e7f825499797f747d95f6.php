<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <div class="max-w-full">
        <img class="h-auto max-w-full" src="/images/Banner-Mantita-Cumple-Mes.jpg" alt="image description">
    </div>


    <div>
        <section class="  mt-14 mb-28">
            <div class="py-8 px-4 mx-auto bg-gray-50 bg-opacity-80 border rounded-2xl text-center lg:py-6"
                style="max-width: 1000px;">
                <h3 style="color:#706D6A"
                    class="mb-4 text-xl font-regular tracking-tight leading-none  md:text-2xl lg:text-4xl dark:text-white">
                    ¡Participa en nuestro concurso<br> #CreceConBambino y gana increíbles premios!</h3>
                <p class="mb-8 text-lg font-normal text-gray-500 lg:text-xl sm:px-6 lg:px-6 dark:text-gray-400">
                    Registra el crecimiento de tu bebé mes a mes <br>con nuestra Mantita Cumple Mes Bambino y podrás
                    ganar:<br><br><strong>Premios mensuales:</strong> Se sortearán mensualmente 2 gift cards de $30.000
                    cada
                    una para usar en
                    www.bambino.cl entre las fotos subidas a la plataforma concursobambino.cl.
                </p>
                <p class="mb-8 text-lg font-normal text-gray-500 lg:text-xl sm:px-6 lg:px-6 dark:text-gray-900">
                    <strong>Gran premio:</strong> ¡La celebración del primer cumpleaños de tu bebé, <strong>valorizada
                        en
                        $300.000</strong> aprox!
                </p>
            </div>

            <div class="py-8 px-4 mx-auto  text-center lg:py-6" style="max-width: 1000px;">
                <h2 class="mb-2 text-lg font-semibold text-gray-900 dark:text-white">Cómo participar:</h2>

                <div class="mx-auto text-center m-12" style="max-width: 600px;">
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/EUOC7VXG0cQ?si=xyq3ZMp1eR2WU6ln"
                        title="YouTube video player" frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                </div>
                <ul
                    class="mb-8 text-lg text-left p-8 border rounded-2xl text-gray-600 bg-opacity-80 bg-gray-100 list-inside dark:text-gray-400">
                    <li class="flex items-center">
                        <svg class="w-3.5 h-3.5 me-2 text-yellow-800 dark:text-green-400 shrink-0" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                        </svg>
                        Usa tu mantita cumple mes de Bambino o adquiérela en nuestra tienda online
                    </li>
                    <li class="flex items-baseline">
                        <svg class="w-3.5 h-3.5 me-2 text-yellow-800 dark:text-green-400 shrink-0" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                        </svg>
                        Toma una foto cada cumple mes de tu bebe sobre la Mantita destacando el mes
                        correspondiente (ver video).
                    </li>
                    <li class="flex items-center">
                        <svg class="w-3.5 h-3.5 me-2 text-yellow-800 dark:text-green-400 shrink-0" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                        </svg>
                        Publica la foto en una historia de Instagram etiquetando el hashtag #crececonbambino.
                    </li>
                    <li class="flex items-center">
                        <svg class="w-3.5 h-3.5 me-2 text-yellow-800 dark:text-green-400 shrink-0" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                        </svg>
                        Sube la foto en nuestra plataforma de concurso concursobambino.cl
                    </li>

                </ul>



                <div class="flex flex-col space-y-4 gap-4 sm:flex-row sm:justify-center sm:space-y-0">
                    <a href="https://www.bambino.cl/products/mantita-muselina-meses-blanco-mapache-nino" target="_blank"
                        class="inline-flex justify-center items-center py-3 px-5 text-base font-medium text-center text-white rounded-lg bg-indigo-800 hover:bg-indigo-600 focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-900">
                        Comprar Mantita Niño
                        <svg class="w-3.5 h-3.5 ms-2 rtl:rotate-180" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M1 5h12m0 0L9 1m4 4L9 9" />
                        </svg>
                    </a>
                    <a href="https://www.bambino.cl/products/mantita-muselina-meses-blanco-flores-nina" target="_blank"
                        class="inline-flex justify-center items-center py-3 px-5 text-base font-medium text-center text-white rounded-lg bg-red-400 hover:bg-red-300 focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-900">
                        Comprar Mantita Niña
                        <svg class="w-3.5 h-3.5 ms-2 rtl:rotate-180" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M1 5h12m0 0L9 1m4 4L9 9" />
                        </svg>
                    </a>

                </div>

                <h2 class="mb-2 mt-8 text-lg font-regular text-gray-900 dark:text-white"> Duración del concurso: Del 3
                    de
                    febrero al 30 de septiembre de 2025.</h2>

                <h2 class="mb-2 text-lg font-regular text-gray-900 dark:text-white">Anunciaremos a los ganadores cada
                    mes en nuestras redes sociales.</h2>
            </div>
        </section>

    </div>





    <div class="w-full md:w-auto">
        <div class="mx-auto" style="max-width: 800px;">
            <form action="<?php echo e(route('participantes.store')); ?>" class="p-8" method="post" enctype="multipart/form-data"
                id="formulario">
                <?php echo csrf_field(); ?>
                <div class="grid gap-6 mb-6 md:grid-cols-2">
                    <div>
                        <label for="first_name"
                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Nombre
                            Madre, Padre o Tutor</label>
                        <input type="text" id="first_name" name="nombretutor" value="<?php echo e(old('nombretutor')); ?>"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                        <?php $__errorArgs = ['nombretutor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="color:red"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="last_name"
                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Apellido
                            Madre, Padre o Tutor</label>
                        <input type="text" id="last_name" name="apellidotutor" value="<?php echo e(old('apellidotutor')); ?>"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                        <?php $__errorArgs = ['apellidotutor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="color:red"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="email" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Email
                            Madre, Padre o Tutor</label>
                        <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="color:red"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="telefono"
                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Celular
                            Madre, Padre o Tutor</label>
                        <input type="tel" id="telefono" name="telefono" value="<?php echo e(old('telefono')); ?>"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                        <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="color:red"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                </div>
                <div class="mb-6">
                    <label for="nombrebebe" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Nombre
                        de tu bebé</label>
                    <input type="text" id="nombrebebe" name="nombrebebe" value="<?php echo e(old('nombrebebe')); ?>"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                    <?php $__errorArgs = ['nombrebebe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color:red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="grid gap-6 mb-6 md:grid-cols-2">
                    <div class="mb-6">
                        <label for="genero" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Fecha
                            de
                            Nacimiento</label>
                        <div class="relative max-w-sm">

                            <div class="absolute inset-y-0 start-0 flex items-center ps-3.5 pointer-events-none">
                                <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                    <path
                                        d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
                                </svg>
                            </div>
                            <input datepicker id="default-datepicker" name="nacimiento" type="text"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                placeholder="Seleciona fecha de nacimiento" value="<?php echo e(old('nacimiento')); ?>">
                            <?php $__errorArgs = ['nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color:red"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="mb-6">
                        <label for="genero" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Sexo de
                            tu bebé</label>
                        <select id="genero" name="sexo"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                            <option value="" <?php echo e(old('sexo') == '' ? 'selected' : ''); ?>>Elije el sexo</option>
                            <option value="Niña" <?php echo e(old('sexo') == 'Niña' ? 'selected' : ''); ?>>Niña</option>
                            <option value="Niño" <?php echo e(old('sexo') == 'Niño' ? 'selected' : ''); ?>>Niño</option>

                        </select>
                        <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p style="color:red"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>


                <div class="mb-6">
                    <label for="direccion" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Tu
                        dirección</label>
                    <input type="text" id="direccion" name="direccion" value="<?php echo e(old('direccion')); ?>"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color:red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="col-span-full">
                    <label for="cover-photo" class="block text-sm/6 font-medium text-gray-900">Foto de tu bebé</label>
                    <div
                        class="mt-2 flex bg-white justify-center rounded-lg border border-dashed border-gray-900/25 px-6 py-10">
                        <div class="text-center">
                            <svg class="mx-auto size-12 text-gray-300" viewBox="0 0 24 24" fill="currentColor"
                                aria-hidden="true" data-slot="icon">
                                <path fill-rule="evenodd"
                                    d="M1.5 6a2.25 2.25 0 0 1 2.25-2.25h16.5A2.25 2.25 0 0 1 22.5 6v12a2.25 2.25 0 0 1-2.25 2.25H3.75A2.25 2.25 0 0 1 1.5 18V6ZM3 16.06V18c0 .414.336.75.75.75h16.5A.75.75 0 0 0 21 18v-1.94l-2.69-2.689a1.5 1.5 0 0 0-2.12 0l-.88.879.97.97a.75.75 0 1 1-1.06 1.06l-5.16-5.159a1.5 1.5 0 0 0-2.12 0L3 16.061Zm10.125-7.81a1.125 1.125 0 1 1 2.25 0 1.125 1.125 0 0 1-2.25 0Z"
                                    clip-rule="evenodd" />
                            </svg>
                            <div class="mt-4 flex text-sm/6 text-gray-600">
                                <label for="file-upload"
                                    class="relative cursor-pointer rounded-md bg-white font-semibold text-indigo-600 focus-within:ring-2 focus-within:ring-indigo-600 focus-within:ring-offset-2 focus-within:outline-hidden hover:text-indigo-500">
                                    <span>Subir imagen</span>
                                    <input id="file-upload" name="imagen" type="file" class="sr-only">
                                    <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p style="color:red"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                            </div>
                            <p class="text-xs/5 text-gray-600">PNG, JPG, GIF máximo 2MB</p>
                        </div>
                    </div>
                </div>
                <div class="flex items-start mb-6 mt-8">
                    <div class="flex items-center h-5">
                        <input id="aceptoTerminos" type="checkbox" name="acepto" value="1"
                            class="w-4 h-4 border border-gray-300 rounded-sm bg-gray-50 focus:ring-3 focus:ring-blue-300 dark:bg-gray-700 dark:border-gray-600 dark:focus:ring-blue-600 dark:ring-offset-gray-800"
                            required />
                    </div>
                    <label for="remember" class="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300">Leí y Acepto
                        las
                        <a href="#" class="text-blue-600 hover:underline dark:text-blue-500">Bases del
                            concuso</a>.</label>
                </div>
                <button type="submit" id="submitButton" disabled
                    class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Enviar
                    datos</button>
            </form>
        </div>



    </div>

    <div class="py-8 px-4 mx-auto  text-center lg:py-6" style="max-width: 1000px;">
        <p class="mt-8 text-lg font-normal text-gray-800 lg:text-md sm:px-6 lg:px-6 dark:text-gray-900">¡No pierdas la
            oportunidad de crear recuerdos inolvidables y ganar fabulosos premios!</p>
        <p class="mt-2 text-sm font-normal text-stone-600 lg:text-sm sm:px-6 lg:px-6 dark:text-gray-900">
            #CrececonBambino #BambinoChile #ConcursoBambino #PrimerCumpleaños #MomentosInolvidables</p>
    </div>
    <?php if(session('scroll_to')): ?>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                let element = document.getElementById("<?php echo e(session('scroll_to')); ?>");
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth' });
                }
            });
        </script>
    <?php endif; ?>

    <script>
        // Selecciona el checkbox de términos y el botón de envío
        const checkboxTerminos = document.getElementById('aceptoTerminos');
        const submitButton = document.getElementById('submitButton');

        // Escucha el cambio en el estado del checkbox
        checkboxTerminos.addEventListener('change', () => {
            // Habilita o deshabilita el botón según el estado del checkbox
            submitButton.disabled = !checkboxTerminos.checked;
        });
    </script>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?><?php /**PATH C:\Users\Usuario\Desktop\mantita\mantitas\resources\views/example.blade.php ENDPATH**/ ?>