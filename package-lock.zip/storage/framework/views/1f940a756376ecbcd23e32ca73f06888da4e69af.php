<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <div class="max-w-full">
        <img class="h-auto max-w-full" src="/images/Banner-Mantita-Cumple-Mes.jpg" alt="image description">
    </div>


    <div>
        <section class="  mt-14 mb-28">
            <div class="py-8 px-4 mx-auto bg-gray-50 bg-opacity-80 border rounded-2xl text-center lg:py-6"
                style="max-width: 1000px;">
                <h3 style="color:#706D6A"
                    class="mb-4 text-xl font-regular tracking-tight leading-none  md:text-2xl lg:text-4xl dark:text-white">
                    ¡Gracias por participar en nuestro concurso<br> #CreceConBambino!</h3>

                <p class="mb-8 text-lg font-normal text-gray-500 lg:text-xl sm:px-6 lg:px-6 dark:text-gray-900">
                    Anunciaremos a los ganadores cada mes en nuestras redes sociales.!
                </p>
            </div>

        </section>

    </div>






    <div class="py-8 px-4 mx-auto  text-center lg:py-6" style="max-width: 1000px;">
        <p class="mt-8 text-lg font-normal text-gray-800 lg:text-md sm:px-6 lg:px-6 dark:text-gray-900">¡No pierdas la
            oportunidad de crear recuerdos inolvidables y ganar fabulosos premios!</p>
        <p class="mt-2 text-sm font-normal text-stone-600 lg:text-sm sm:px-6 lg:px-6 dark:text-gray-900">
            #CrececonBambino #BambinoChile #ConcursoBambino #PrimerCumpleaños #MomentosInolvidables</p>
    </div>




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?><?php /**PATH C:\Users\Usuario\Desktop\mantita\mantitas\resources\views/gracias.blade.php ENDPATH**/ ?>