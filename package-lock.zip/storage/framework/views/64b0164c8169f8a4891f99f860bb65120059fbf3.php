<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 

     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 text-center">


                    <div
                        class="max-w-sm text-center img-card bg-white border border-gray-200 rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700">

                        <img class="rounded-t-lg text-center" src="<?php echo e(asset('images/' . $participante->imagen)); ?>"
                            alt="" />

                        <div class="p-5">
                            <a href="#">
                                <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                                    <?php echo e($participante->nombrebebe); ?>

                                </h5>
                            </a>
                            <ul
                                class="w-full text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                <li class="w-full px-4 py-2 border-b border-gray-200 rounded-t-lg dark:border-gray-600">
                                    Fecha de nacimiento: <?php echo e($participante->nacimiento); ?></li>
                                <li class="w-full px-4 py-2 border-b border-gray-200 rounded-t-lg dark:border-gray-600">
                                    Sexo bebé: <?php echo e($participante->sexo); ?></li>
                                <li class="w-full px-4 py-2 border-b border-gray-200 rounded-t-lg dark:border-gray-600">
                                    Nombre Tutor: <?php echo e($participante->nombretutor); ?> <?php echo e($participante->apellidotutor); ?></li>
                                <li class="w-full px-4 py-2 border-b border-gray-200 dark:border-gray-600">Email:
                                    <?php echo e($participante->email); ?>

                                </li>
                                <li class="w-full px-4 py-2 border-b border-gray-200 dark:border-gray-600">Teléfono:
                                    <?php echo e($participante->telefono); ?>

                                </li>
                                <li class="w-full px-4 py-2 rounded-b-lg">Dirección: <?php echo e($participante->direccion); ?></li>
                            </ul>
                            <div class="flex gap-2 mb-5 mt-5">

                                <div>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('toggle-selection', ['participante' => $participante])->html();
} elseif ($_instance->childHasBeenRendered('d53BuKy')) {
    $componentId = $_instance->getRenderedChildComponentId('d53BuKy');
    $componentTag = $_instance->getRenderedChildComponentTagName('d53BuKy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('d53BuKy');
} else {
    $response = \Livewire\Livewire::mount('toggle-selection', ['participante' => $participante]);
    $html = $response->html();
    $_instance->logRenderedChild('d53BuKy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                        </div>
                    </div>





                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\Usuario\Desktop\mantita\mantitas\resources\views/participantes/show.blade.php ENDPATH**/ ?>